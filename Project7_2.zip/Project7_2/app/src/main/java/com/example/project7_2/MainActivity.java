package com.example.project7_2;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class MainActivity extends AppCompatActivity {

    Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.button1);

        final String[] versionArray = new String[] {"Android 10","Android 11","Android 12"};
        final boolean[] checkArray = new boolean[] {false, false, false};

        AlertDialog.Builder dig = new AlertDialog.Builder(MainActivity.this);

        dig.setTitle("사용하고 있는 버전은?") //연결해서 사용하는 것이 가독성이 좋다
        .setIcon(R.mipmap.ic_launcher)
        .setMultiChoiceItems(versionArray, checkArray, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {

              button1.setText(versionArray[which]);
            }
        })
        .setPositiveButton("확인",null)
        .show();




    }
}