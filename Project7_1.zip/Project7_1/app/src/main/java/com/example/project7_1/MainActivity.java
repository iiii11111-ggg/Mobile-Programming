package com.example.project7_1;

import android.content.ClipData;
import android.graphics.Color;
import android.media.RouteListingPreference;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity extends AppCompatActivity {


    LinearLayout baseLayout;
    Button btnChange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        baseLayout = findViewById(R.id.baseLayout);
        btnChange = findViewById(R.id.btnMenu);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int itemId = item.getItemId();


        if(itemId == R.id.itemRed){
            baseLayout.setBackgroundColor(Color.RED);
        } else if (itemId == R.id.itemGreen){
            baseLayout.setBackgroundColor(Color.GREEN);
        }
        else if (itemId == R.id.itemBlue){
            baseLayout.setBackgroundColor(Color.BLUE);
        }
        else if (itemId == R.id.subRotate){

            btnChange.setRotation(45);
        }
        else if (itemId == R.id.subSize){

            btnChange.setScaleX(2);
        }




        return true;
    }
}