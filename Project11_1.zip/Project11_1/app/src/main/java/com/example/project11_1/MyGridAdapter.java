package com.example.project11_1;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import androidx.appcompat.app.AlertDialog;


public class MyGridAdapter extends BaseAdapter {


    View dlgView;
    ImageView ivPoster;



    Context context;
    public MyGridAdapter(Context _context) {
        context = _context;
        posterID
    }

    @Override
    public int getCount() {
        return posterID.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //GridView에 출력할 ImageView를 생성 후 이미지 출력

        //Context.getResource(R.color.white); 시스템 자원 가져오기

        ImageView ivG = new ImageView(context);
        ivG.setLayoutParams(new GridView.LayoutParams(250,200));
        ivG.setScaleType(ImageView.ScaleType.FIT_CENTER);

        ivG.setImageResource(posterID[position]);

        final int pos = position;
        AlertDialog.Builder dlg = new AlertDialog.Builder(context);
        ivG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dlgView = View.inflate(context,R.layout.dialog,null);
                ivPoster = dlgView.findViewById(R.id.ivPoster);
                ivPoster.setImageResource(posterID[pos]);

                dlg.setTitle(posterName[pos]);
                dlg.setIcon(R.drawable.movie_icon);
                dlg.setView(dlgView);
                dlg.setNegativeButton("닫기",null);
                dlg.show();
            }
        });

        return ivG;
    }
}